/* 基础设定 */

const BASIC = {
	domBasic:{
		size: "12",
		background:"",
		fontWeight:"",
		bold:"",
		lineHeight:"",
		color:""
	},
	game2048:{
		start:"", //开始
		end:"", //结束
		delay:"", //延迟
		background:[], //背景色
	}
	
}